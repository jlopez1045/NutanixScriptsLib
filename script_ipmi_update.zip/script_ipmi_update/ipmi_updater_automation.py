#!/usr/bin/env python3

# vim: autoindent tabstop=4 shiftwidth=4 expandtab softtabstop=4 filetype=python
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 51
# Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#
# Created by Jay.Lopez@Nutanix.com 10/22/24

# libraries needed:
# pip install requests, pyOpenSSL, columnar

import os
import sys
import re
import inspect
import subprocess
from datetime import datetime
from base64 import b64encode
import random
import string
import getopt
import concurrent.futures
import urllib.parse

import requests
from OpenSSL import crypto
from columnar import columnar


version = '1.0'
scriptfolder = os.path.dirname(os.path.abspath(__file__))
scriptname = os.path.basename(os.path.realpath(__file__))
# print(f'*** Created by Jay.Lopez@Nutanix.com')
# print(f'*** Ver: {version} {scriptname}')

REQUEST_TIMEOUT = 5.0


# ============================================================================================================================================================================================== GENERAL


def get_arg_var():

    try:
        srv_list = ''

        help_print_out = str(f'py {scriptname}' + '\n' +
                             f'py {scriptname} -c <pclist.txt>')

        opts, args = getopt.getopt(sys.argv[1:], "h:c:", ['help', 'pclist='])

        for opt, arg in opts:
            # print(opt, arg)
            if opt in ('-h', '--help'):
                print(help_print_out)
                sys.exit()
            elif opt in ('-c', '--pclist'):
                pc_file = open(str(arg), 'r')
                srv_list = pc_file.readlines()

        # print('get_arg_var', pc_list)
        return srv_list

    except Exception as msg:
        print('Failure.......', inspect.currentframe().f_code.co_name, 'Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(msg).__name__, msg)


def export_results(filename, headers, results_list, sort_column):

    sorted_list = [list(x) for x in set(tuple(x) for x in results_list)]
    sorted_list = sorted(sorted_list, key=lambda x: x[sort_column])
    sorted_list = [[str(item).upper() for item in sublist] for sublist in sorted_list]

    table = columnar(sorted_list, headers, terminal_width=800, min_column_width=25, max_column_width=100, no_borders=True)

    # print(table)

    now = datetime.now()
    date_time_str = now.strftime("%Y%m%d")
    newfolderpath = scriptfolder + "\\" + 'out_' + os.path.splitext(scriptname)[0]
    create_folder(newfolderpath)
    create_file(newfolderpath + "\\" + f'{filename}_' + str(date_time_str), table)

    return table


def ping(host):
    response = subprocess.run(["ping", "-n", "1", host], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # print(host, response)
    if response.returncode == 0:
        # print(host, 'Ping True')
        return True
    else:
        # print(host, 'Ping False')
        return False


def is_ipv4_address(s):
    parts = s.split('.')
    if len(parts) != 4:
        return False
    for part in parts:
        if not part.isdigit():
            return False
        num = int(part)
        if num < 0 or num > 255:
            return False
    return True


def create_folder(new_directory_name):
    try:
        if not os.path.exists(new_directory_name):
            os.mkdir(new_directory_name)
    except Exception as msg:
        print('=====', inspect.currentframe().f_code.co_name, 'Error on line {}'.format(sys.exc_info()[-1].tb_lineno),
              msg)
        sys.exit()


def create_file(file, data):
    try:
        with open(file + '.txt', 'a+') as file:
            file.write('-------------------------------------------------------------------------------')
            file.write('\n')
            file.write(str(data))
            file.write('\n')

    except Exception as msg:
        print('=====', inspect.currentframe().f_code.co_name, 'Error on line {}'.format(sys.exc_info()[-1].tb_lineno),
              msg)
        sys.exit()


def generate_random_string(length=16):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))


# ============================================================================================================================================================================================== OPENSSL


def create_cert_and_key():
    # Generate a new key pair
    key = crypto.PKey()
    key.generate_key(crypto.TYPE_RSA, 2048)

    # Create a self-signed certificate
    cert = crypto.X509()
    cert.get_subject().C = "US"
    cert.get_subject().ST = "STATE"
    cert.get_subject().L = "CITY"
    cert.get_subject().O = "NUTANIX"
    cert.get_subject().OU = "IT5"
    cert.get_subject().CN = "localhost"
    cert.set_serial_number(1000)
    cert.gmtime_adj_notBefore(0)
    cert.gmtime_adj_notAfter(10*365*24*60*60)  # 10 years
    cert.set_issuer(cert.get_subject())
    cert.set_pubkey(key)
    cert.sign(key, 'sha256')

    cert_file_name = 'cert.pem'
    key_file_name = 'key.pem'

    # Write the key and certificate to files in PEM format
    with open(cert_file_name, 'wb') as cert_out:
        cert_out.write(crypto.dump_certificate(crypto.FILETYPE_PEM, cert))
    with open(key_file_name, 'wb') as key_out:
        key_out.write(crypto.dump_privatekey(crypto.FILETYPE_PEM, key))

    return cert_file_name, key_file_name


# =========================================================================================================================================================================================== Automation


def task(srv):
    results_dict.update({srv: 'STARTING'})

    if ping(srv):

        try:
            script_path = os.path.join(scriptfolder, 'ipmi_updater.py')
            result = subprocess.run([
                sys.executable, script_path,
                '--ipmi-url', f'https://{srv}',
                '--username', ilo_username,
                '--password', ilo_password,
                '--cert', cert_file,
                '--key', key_file], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=REQUEST_TIMEOUT)

            # Output the result
            # print("Return Code:", result.returncode)
            # print("Output:", result.stdout.decode("utf-8"))
            # print("Error (if any):", result.stderr.decode("utf-8"))

            results_dict.update({srv: f'DONE {result.stdout.decode("utf-8")}'})

            if not result:
                results_dict.update({srv: 'FAILED'})

        except Exception as msg:
            # print('ERROR', msg)
            results_dict.update({srv: f'FAILED {msg}'})

    else:
        results_dict.update({srv: 'FAILED PING'})


if __name__ == "__main__":
    try:

        print('************************************************************ START ************************************************************', f'Ver: {version}')

        results_dict = {}

        # To skip prompts for testing and use hardcoded values set is_dev = True
        is_dev = False

        if is_dev:
            ilo_username = 'ADMIN'
            ilo_password = 'ADMIN'
            srv_list = ['x.x.x.x']
            create_ssl = 'Y'
        else:
            ilo_username = input('Please enter your iLo Username: ')
            ilo_password = input('Please enter your iLo Password: ')
            create_ssl = input('Do you want to create a new SSL certificate? (Y/N): ').upper()
            srv_list = get_arg_var()

        if create_ssl[0] == 'Y':
            create_ssl = True
            cert_file, key_file = create_cert_and_key()
        else:
            create_ssl = False
            cert_file = input('Please enter the path to the certificate file: ')
            key_file = input('Please enter the path to the key file: ')

        if srv_list == '':
            srv = input('Please enter the IP of the iLO: ')
            srv_list = [str(srv)]

        newfolderpath = scriptfolder + "\\" + 'out_' + os.path.splitext(scriptname)[0]
        create_folder(newfolderpath)

        print('************************************************************ RUNNING **********************************************************')

        final_srv_list = []
        for srv in srv_list:
            if (srv == '') or ('#' in srv) or (srv is None) or (srv.isspace()):
                continue
            else:
                srv = str(srv).strip()
                if is_ipv4_address(srv):
                    pass

                final_srv_list.append(srv)

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
            list(executor.map(task, final_srv_list))

        print('********************************************************** SUMMARY ************************************************************')

        tbl_headers = ['Entity', 'Message']
        tbl_list = []
        for k, v in results_dict.items():
            tbl_list.append([str(k), str(v)])
        results_out = export_results(filename='results', headers=tbl_headers, results_list=tbl_list, sort_column=0)
        print(results_out)

        print('************************************************************ END **************************************************************')

    except Exception as msg:
        print('Failure.......', inspect.currentframe().f_code.co_name, 'Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(msg).__name__, msg)
        sys.exit()